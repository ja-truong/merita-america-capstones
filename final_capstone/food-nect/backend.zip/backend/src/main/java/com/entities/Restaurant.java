package com.entities;

import lombok.*;

import javax.persistence.*;
import java.util.Set;


@Entity
@Table(name="restaurant_tbl")

public class Restaurant {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    //@Column(name="id")
    private int id;
    private String restaurantName;
    private String restaurantType;
    private String completeAddress;
    private String zipCode;
    private String city;
    private String imagePath;
    private String telnum;
    private Boolean isVegan;
    private String description;
    private String openFrom;
    private String openTo;

    @OneToMany
    @JoinColumn(name = "id")
    private Set<RestoFromLink> restoFromLinkSet;

    public Restaurant() {
    }

    public Restaurant(int id, String restaurantName, String restaurantType, String completeAddress, String zipCode, String city, String imagePath, String telnum, Boolean isVegan, String description, String openFrom, String openTo, Set<RestoFromLink> restoFromLinkSet) {
        this.id = id;
        this.restaurantName = restaurantName;
        this.restaurantType = restaurantType;
        this.completeAddress = completeAddress;
        this.zipCode = zipCode;
        this.city = city;
        this.imagePath = imagePath;
        this.telnum = telnum;
        this.isVegan = isVegan;
        this.description = description;
        this.openFrom = openFrom;
        this.openTo = openTo;
        this.restoFromLinkSet = restoFromLinkSet;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRestaurantName() {
        return restaurantName;
    }

    public void setRestaurantName(String restaurantName) {
        this.restaurantName = restaurantName;
    }

    public String getRestaurantType() {
        return restaurantType;
    }

    public void setRestaurantType(String restaurantType) {
        this.restaurantType = restaurantType;
    }

    public String getCompleteAddress() {
        return completeAddress;
    }

    public void setCompleteAddress(String completeAddress) {
        this.completeAddress = completeAddress;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public String getTelnum() {
        return telnum;
    }

    public void setTelnum(String telnum) {
        this.telnum = telnum;
    }

    public Boolean getVegan() {
        return isVegan;
    }

    public void setVegan(Boolean vegan) {
        isVegan = vegan;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getOpenFrom() {
        return openFrom;
    }

    public void setOpenFrom(String openFrom) {
        this.openFrom = openFrom;
    }

    public String getOpenTo() {
        return openTo;
    }

    public void setOpenTo(String openTo) {
        this.openTo = openTo;
    }

    public Set<RestoFromLink> getRestoFromLinkSet() {
        return restoFromLinkSet;
    }

    public void setRestoFromLinkSet(Set<RestoFromLink> restoFromLinkSet) {
        this.restoFromLinkSet = restoFromLinkSet;
    }
}