package com.foodnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
